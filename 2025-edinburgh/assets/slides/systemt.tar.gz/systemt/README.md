# Logical relation for SystemT formalised

This is a simple, self-contained formalisation of some of the content
of the lecture in Rocq/Coq. The style of the semantics and calculus
differ slightly from the presentation in the lecture notes, in order
to streamline the formalisation somewhat. I will go over the main
differences below.

## The language [`Lang.v`]

Instead of splitting the terms of the language into syntactic
categories of values and expressions, we only keep expressions. This
makes writing example programs slightly simpler. We also use a variant
of intrinsically well-scoped syntax to represent the available free
variables (as a set over which the expressions are
parameterised). Binding is represented by *extending* the set. 

The typing judgment is parameterised over the typing *context* (which
consists of a domain and a mapping from it to types; incidentally,
both `Scope.v` and `Context.v` are small parts of an existing but as
yet unpublished library for representing and reasoning about
binding). The rules are pretty much as one would expect.

The semantics is significantly different from the lecture notes:
instead of a simple structural operational semantics I went with a
big-step environment semantics. This avoids the need for meta-level
substitution operation (and thus a binding library support), but does
require some additional semantic artifacts: runtime values,
computations and environments. Runtime values comprise natural numbers
(note, these are actual, meta-level numbers!) as well as functional
values; these latter ones consist of a body of a lambda and an
almost-closing environment. Environments simply map their domains to
runtime values. Finally, computations crucially allow open expressions
together with closing environments, as well as two auxiliary
constructs: applications of values, and recursors applied to a
number. These latter constructs are not strictly necessary, but make
presentation simpler. Note that the structure we chose already commits
us to a call-by-value semantics: for call-by-name, environments would
need to store computations!

Finally, operational semantics is given as a big-step relation,
relating a computation with its value: the rules are mostly
straightforward, and match closely to a standard environment-based
interpreter.

## Unary [`Interp.v`] and Binary [`InterpBin.v`] Interpretations

The interpretation differs only slightly from what we could see in the
lecture slides: for convenience, I start by introducing a notion of
interpretations of values and computations (respectively as predicates
or relations on runtime values/computations, as appropriate). Then, I
define combinators for "closure under evaluation" (`EC`) as well as
for our types: natural numbers and arrows. This allows the recursive
definition of the interpretation to be rather clean and
compact. Finally, we can extend the interpretation pointwise for
interpretation of contexts, and define the logical relation itself.
Note that the logical relation works on open *expressions* and uses
the closing environment to construct a — closed by construction! —
computation.

These definitions allow us to state and prove the compatibility
lemmas, and from those the fundamental theorem of logical
relations. In the both cases, termination follows immediately;
however, in the binary case we need some additional work to relate our
notion to observational equivalence. To this end, we introduce
(potentially) binding contexts, `CC`. These can have multiple holes,
as long as all the holes agree on the set of free variables that can
occur in a term to be plugged into them. Finally, we can define our
observation on computations (i.e., complete running programs) and the
notion of contextual equivalence, and prove compatibility and
adequacy. We can also formally prove our running example of a simple
program equivalence.

## Notes

* We could approach System F similarly, but at that point it is not
  easy to avoid having to deal with substitution (due to the fact that
  we substitute types in types within typing rules for quantifiers).
* On paper, single-hole binding contexts are more commonly used, but
  these are less streamlined in practice. If dealing with meta-level
  substitutions, an even more general form can be used, where hole
  occurrences are decorated with substitutions that mediate between
  the scope of the hole and the scope expected by the context. One can
  also easily generalise the definition to handle multiple
  "metavariables"/holes, each with many possible occurrences.
* The environment-based approach can be applied to small-step
  semantics as well, although that tends to increase the number of
  constructor of runtime computations quite significantly
* Note that there is no static type system for values/computations,
  yet we can easily derive a type safety result from our logical
  relation (depending on formulation, may also require determinism of
  the semantics): this is, fundamentally, what we've seen in Robert's
  lecture for much more complex languages.
* The original System T is neither call-by-value, nor a programming
  language in a modern sense (it is given with a call-by-name
  equational theory); still, I feel it makes sense to use this name
  for a language with simply-typed, higher order functions and natural
  numbers with primitive recursion as the main drivers of computation.
