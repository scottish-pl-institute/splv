Require Import Utf8.
Require Import Context.

(** Syntax *)
Inductive expr {V : Set} :=
| var  : V → expr
| lam : @expr (inc V) → expr
| zero : expr
| succ : expr → expr
| app : expr → expr → expr
| rec : expr → expr → expr → expr.
Arguments expr V : clear implicits.

(** Types *)
Inductive type : Set :=
| t_nat : type
| t_arrow : type → type → type
.

Notation "σ ⇒ τ" := (t_arrow σ τ) (at level 35, right associativity).

(** Typing relation *)
Reserved Notation "Γ ⊢ e : τ" (at level 70, no associativity, e, τ at level 40).

Inductive types (Γ : Ctx type) : expr (dom Γ) → type → Prop :=
| T_var x : Γ ⊢ var x : Γ x
| T_zero : Γ ⊢ zero : t_nat
| T_succ e (HT : Γ ⊢ e : t_nat) : Γ ⊢ succ e : t_nat
| T_lam σ τ e (HT : Γ ▹ σ ⊢ e : τ) :
  Γ ⊢ lam e : σ ⇒ τ
| T_app σ τ e₁ e₂ (HT₁ : Γ ⊢ e₁ : σ ⇒ τ) (HT₂ : Γ ⊢ e₂ : σ) :
  Γ ⊢ app e₁ e₂ : τ
| T_rec σ e ez es (HT : Γ ⊢ e : t_nat) (HT₁ : Γ ⊢ ez : σ) (HT₂ : Γ ⊢ es : σ ⇒ σ) :
  Γ ⊢ rec e ez es : σ
where "Γ ⊢ e : τ" := (types Γ e τ).

(** Runtime values, environments and computations *)
Inductive val :=
| vlam {X : Set} (e : expr (inc X)) (ρ : X → val)
| vnat (n : nat).

Definition env (X : Set) := X → val.

Inductive comp :=
| cev {X : Set} (e : expr X) (ρ : env X)
| capp (u v : val)
| crec (n : nat) (vz vs : val).

(** Evaluation (big-step) *)

Reserved Notation "c ⇓ v" (at level 70, no associativity).

Inductive eval : comp → val → Prop :=
| E_var {X} x (ρ : env X) : cev (var x) ρ ⇓ ρ x
| E_zero {X} (ρ : env X) : cev zero ρ ⇓ vnat 0
| E_succ {X} e (ρ : env X) n
    (HE : cev e ρ ⇓ vnat n) :
  cev (succ e) ρ ⇓ vnat (S n)
| E_lam {X} e (ρ : env X) : cev (lam e) ρ ⇓ vlam e ρ
| E_app {X} e₁ e₂ (ρ : env X) u₁ u₂ u
    (HE₁ : cev e₁ ρ ⇓ u₁)
    (HE₂ : cev e₂ ρ ⇓ u₂)
    (HE : capp u₁ u₂ ⇓ u) :
  cev (app e₁ e₂) ρ ⇓ u
| E_rec {X} e ez es n uz us (ρ : env X) u
    (HEz : cev ez ρ ⇓ uz)
    (HEs : cev es ρ ⇓ us)
    (HEn : cev e  ρ ⇓ (vnat n))
    (HER : crec n uz us ⇓ u) :
  cev (rec e ez es) ρ ⇓ u
| E_capp {X} e (ρ : env X) u v 
    (HE : cev e (ρ ▷ u) ⇓ v) :
  capp (vlam e ρ) u ⇓ v
| E_recz vz vs :
  crec 0 vz vs ⇓ vz
| E_recs n vz vs u v
    (HER : crec n vz vs ⇓ u)
    (HES : capp vs u ⇓ v) :
  crec (S n) vz vs ⇓ v
where "c ⇓ v" := (eval c v).
