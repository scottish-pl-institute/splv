Require Import Utf8.
Require Import Context.
Require Import Lang.

Definition VT := val  → Prop.
Definition CT := comp → Prop.

Inductive EC {X : VT} : CT :=
| ev e v (HE : e ⇓ v) (HI : X v) : EC e.
Arguments EC X : clear implicits.

Definition Arr (U V : VT) : VT :=
  λ v, ∀ u (HIu : U u), EC V (capp v u).

Inductive Nat : VT :=
| IN n : Nat (vnat n).

Reserved Notation "'V〚' τ 〛".

Fixpoint interp (τ : type) : VT :=
  match τ with
  | t_nat => Nat
  | σ ⇒ τ => Arr V〚 σ 〛 V〚 τ 〛
  end
where "'V〚' τ 〛" := (interp τ).

Notation "'E〚' τ 〛" := (EC (interp τ)).

Definition interpC (Γ : Ctx type) (γ : dom Γ → val) : Prop :=
  ∀ x, V〚 Γ x 〛 (γ x).
Notation "'C〚' Γ 〛" := (interpC Γ).

Definition logrel (Γ : Ctx type) (e : expr (dom Γ)) (τ : type) :=
  ∀ ρ, C〚 Γ 〛 ρ → E〚 τ 〛 (cev e ρ).
Notation "Γ ⊨ e : τ" := (logrel Γ e τ) (at level 70, no associativity, e, τ at level 40).

Lemma C_var Γ x :
  Γ ⊨ var x : Γ x.
Proof.
  intros ρ HC.
  exists (ρ x); [constructor | apply HC].
Qed.

Lemma C_zero Γ :
  Γ ⊨ zero : t_nat.
Proof.
  intros ρ HC.
  exists (vnat 0); now constructor.
Qed.

Lemma C_succ Γ e
  (HE : Γ ⊨ e : t_nat) :
  Γ ⊨ succ e : t_nat.
Proof.
  intros ρ HC; specialize (HE _ HC).
  inversion HE; subst; clear HE; destruct HI.
  exists (vnat (S n)); now constructor.
Qed.

Lemma C_lam Γ σ τ e
  (HE : Γ ▹ σ ⊨ e : τ) :
  Γ ⊨ lam e : σ ⇒ τ. 
Proof.
  intros ρ HC; exists (vlam e ρ); [now constructor |].
  intros u HIu; specialize (HE (ρ ▷ u) (HC ▷ HIu)).
  inversion HE; subst; clear HE.
  exists v; [now constructor | assumption].
Qed.

Lemma C_app Γ σ τ e₁ e₂
  (HE₁ : Γ ⊨ e₁ : σ ⇒ τ)
  (HE₂ : Γ ⊨ e₂ : σ) :
  Γ ⊨ app e₁ e₂ : τ.
Proof.
  intros ρ HC; specialize (HE₁ ρ HC); specialize (HE₂ ρ HC).
  inversion HE₁; subst; inversion HE₂; subst; clear HE₁ HE₂.
  simpl in *; specialize (HI v0 HI0).
  inversion HI; subst; clear HI.
  exists v1; [econstructor; eassumption | assumption].
Qed.

Lemma C_rec Γ τ e ez es
  (HE : Γ ⊨ e : t_nat)
  (HE₁ : Γ ⊨ ez : τ)
  (HE₂ : Γ ⊨ es : τ ⇒ τ) :
  Γ ⊨ rec e ez es : τ.
Proof.
  intros ρ HC; specialize (HE ρ HC); specialize (HE₁ ρ HC); specialize (HE₂ ρ HC).
  inversion HE; subst; clear HE; destruct HI.
  inversion HE₁; subst; inversion HE₂; subst; clear HE₁ HE₂; simpl in *.
  assert (HH : E〚 τ 〛 (crec n v v0)).
  { clear -HI HI0; induction n.
    - exists v; [constructor | assumption].
    - inversion IHn; subst; clear IHn.
      specialize (HI0 v1 HI1).
      inversion HI0; subst; clear HI0.
      exists v2; [econstructor; eassumption | assumption].
  }
  inversion HH; subst; clear HH.
  exists v1; [econstructor; eassumption | assumption].
Qed.

Lemma ftlr Γ e τ (HT : Γ ⊢ e : τ) : Γ ⊨ e : τ.
Proof.
  induction HT; now eauto using C_var, C_zero, C_succ, C_lam, C_app, C_rec.
Qed.

Lemma termination e τ (HT : □ ⊢ e : τ) : ∃ v, cev e ¡ ⇓ v.
Proof.
  apply ftlr in HT; specialize (HT ¡ ¡).
  revert HT; generalize (cev e ¡) as c; intros c HT.
  destruct HT; now exists v.
Qed.
