Require Import Utf8.
Require Import Context.
Require Import Lang.

Definition VT := val  → val  → Prop.
Definition CT := comp → comp → Prop.

Inductive EC {X : VT} : CT :=
| ev c₁ c₂ v₁ v₂ (HE₁ : c₁ ⇓ v₁) (HE₂ : c₂ ⇓ v₂) (HI : X v₁ v₂) : EC c₁ c₂.
Arguments EC X : clear implicits.

Definition Arr (U V : VT) : VT :=
  λ v₁ v₂, ∀ u₁ u₂ (HIu : U u₁ u₂), EC V (capp v₁ u₁) (capp v₂ u₂).

Inductive Nat : VT :=
| IN n : Nat (vnat n) (vnat n).

Fixpoint interp (τ : type) : VT :=
  match τ with
  | t_nat => Nat
  | σ ⇒ τ => Arr (interp σ) (interp τ)
  end.

Notation "'V〚' τ 〛" := (interp τ).
Notation "'E〚' τ 〛" := (EC (interp τ)).

Definition interpC (Γ : Ctx type) (γ₁ γ₂ : dom Γ → val) : Prop :=
  ∀ x, V〚 Γ x 〛 (γ₁ x) (γ₂ x).

Notation "'C〚' Γ 〛" := (interpC Γ).

Definition logrel (Γ : Ctx type) (e₁ e₂ : expr (dom Γ)) (τ : type) :=
  ∀ ρ₁ ρ₂, C〚 Γ 〛 ρ₁ ρ₂ → E〚 τ 〛 (cev e₁ ρ₁) (cev e₂ ρ₂).
Notation "Γ ⊨ e₁ ≈ e₂ : τ" := (logrel Γ e₁ e₂ τ) (at level 70, no associativity, e₁, e₂, τ at level 40).

Lemma C_var Γ x :
  Γ ⊨ var x ≈ var x : Γ x.
Proof.
  intros ρ₁ ρ₂ HC.
  exists (ρ₁ x) (ρ₂ x); [now constructor .. | apply HC].
Qed.

Lemma C_zero Γ :
  Γ ⊨ zero ≈ zero : t_nat.
Proof.
  intros ρ₁ ρ₂ _; exists (vnat 0) (vnat 0); now constructor.
Qed.

Lemma C_succ Γ e₁ e₂
  (HE : Γ ⊨ e₁ ≈ e₂ : t_nat) :
  Γ ⊨ succ e₁ ≈ succ e₂ : t_nat.
Proof.
  intros ρ₁ ρ₂ HC; specialize (HE _ _ HC).
  inversion HE; subst; clear HC HE; destruct HI.
  exists (vnat (S n)) (vnat (S n)); now constructor.
Qed.

Lemma C_lam Γ σ τ e₁ e₂
  (HE : Γ ▹ σ ⊨ e₁ ≈ e₂ : τ) :
  Γ ⊨ lam e₁ ≈ lam e₂ : σ ⇒ τ. 
Proof.
  intros ρ₁ ρ₂ HC; exists (vlam e₁ ρ₁) (vlam e₂ ρ₂); [now constructor .. |].
  intros u₁ u₂ HIu.
  specialize (HE (ρ₁ ▷ u₁) (ρ₂ ▷ u₂) (HC ▷ HIu)).
  inversion HE; subst; clear HE.
  exists v₁ v₂; [now constructor .. | assumption].
Qed.

Lemma C_app Γ σ τ e₁ e₂ a₁ a₂
  (HE₁ : Γ ⊨ e₁ ≈ e₂ : σ ⇒ τ)
  (HE₂ : Γ ⊨ a₁ ≈ a₂ : σ) :
  Γ ⊨ app e₁ a₁ ≈ app e₂ a₂ : τ.
Proof.
  intros ρ₁ ρ₂ HC; specialize (HE₁ ρ₁ ρ₂ HC); specialize (HE₂ ρ₁ ρ₂ HC).
  inversion HE₁; subst; clear HE₁.
  inversion HE₂; subst; clear HE₂; simpl in *.
  specialize (HI v₁0 v₂0 HI0).
  inversion HI; subst; clear HI.
  exists v₁1 v₂1; [econstructor; eassumption .. | assumption].
Qed.

Lemma C_rec Γ τ e₁ e₂ ez₁ ez₂ es₁ es₂
  (HE : Γ ⊨ e₁ ≈ e₂ : t_nat)
  (HE₁ : Γ ⊨ ez₁ ≈ ez₂ : τ)
  (HE₂ : Γ ⊨ es₁ ≈ es₂ : τ ⇒ τ) :
  Γ ⊨ rec e₁ ez₁ es₁ ≈ rec e₂ ez₂ es₂ : τ.
Proof.
  intros ρ₁ ρ₂ HC; specialize (HE _ _ HC); specialize (HE₁ _ _ HC); specialize (HE₂ _ _ HC).
  inversion HE; subst; clear HE; destruct HI.
  inversion HE₁; subst; clear HE₁.
  inversion HE₂; subst; clear HE₂; simpl in *.
  assert (HH : E〚 τ 〛 (crec n v₁ v₁0) (crec n v₂ v₂0)).
  { clear -HI HI0; induction n.
    - exists v₁ v₂; [now constructor .. | assumption].
    - inversion IHn; subst; clear IHn.
      specialize (HI0 v₁1 v₂1 HI1).
      inversion HI0; subst; clear HI0.
      exists v₁2 v₂2; [econstructor; eassumption .. | assumption].
  }
  inversion HH; subst; clear HH.
  exists v₁1 v₂1; [econstructor; eassumption .. | assumption].
Qed.

Lemma ftlr Γ e τ (HT : Γ ⊢ e : τ) : Γ ⊨ e ≈ e : τ.
Proof.
  induction HT; now eauto using C_var, C_zero, C_succ, C_lam, C_app, C_rec.
Qed.

Definition add {X} : expr X := lam (lam (rec (var (VS VZ)) (var VZ) (lam (succ (var VZ))))).

Lemma add_zeroᵣ : □ ▹ t_nat ⊨ app (app add (var VZ)) zero ≈ var VZ : t_nat.
Proof.
  intros ρ₁ ρ₂ HC; specialize (HC VZ); simpl in HC; inversion HC; subst; clear HC.
  exists (vnat n) (vnat n); [| rewrite H; now constructor | constructor].
  clear H; rename H0 into EQ.
  econstructor; [now repeat econstructor | constructor |].
  simpl in *; rewrite <- EQ; clear EQ; constructor.
  eapply E_rec with (n := n); [constructor .. |].
  generalize (ρ₁ ▷ vnat n : _ → val) as ρ; clear ρ₁ ρ₂; induction n; [now constructor |].
  intros ρ; econstructor; [apply IHn |].
  repeat constructor.
Qed.

(* Capturing contexts with set X of variables available to the hole
   (and outer set Y denoting the variables free from the "outside" of
   the context). Note, each context can contain multiple instances of
   the hole; they do need to match the same binding specification
   though. *)
Inductive CC {X : Set} : Set → Type :=
| CHole : CC X
| CTm {Y} : expr Y → CC Y
| CLam {Y} : CC (inc Y) → CC Y
| CApp {Y} : CC Y → CC Y → CC Y
| CSucc {Y} : CC Y → CC Y
| CRec {Y} : CC Y → CC Y → CC Y → CC Y
.
Arguments CC X Y : clear implicits.

(* Typing of the contexts *)
Inductive CCT Γ τ : ∀ (Δ : Ctx type) (σ : type), CC (dom Γ) (dom Δ) → Prop :=
| CTH : CCT Γ τ Γ τ CHole
| CTT Δ σ e : Δ ⊢ e : σ → CCT Γ τ Δ σ (CTm e)
| CTLam Δ σₐ σᵣ C :
  CCT Γ τ (Δ ▹ σₐ) σᵣ C →
  CCT Γ τ Δ (σₐ ⇒ σᵣ) (CLam C)
| CTApp Δ σₐ σᵣ C₁ C₂ :
  CCT Γ τ Δ (σₐ ⇒ σᵣ) C₁ →
  CCT Γ τ Δ σₐ C₂ →
  CCT Γ τ Δ σᵣ (CApp C₁ C₂)
| CTSucc Δ C :
  CCT Γ τ Δ t_nat C →
  CCT Γ τ Δ t_nat (CSucc C)
| CTRec Δ σ C Cz Cs :
  CCT Γ τ Δ t_nat C →
  CCT Γ τ Δ σ Cz →
  CCT Γ τ Δ (σ ⇒ σ) Cs →
  CCT Γ τ Δ σ (CRec C Cz Cs)
.

Fixpoint plug {X Y} (C : CC X Y) : expr X → expr Y :=
  match C with
  | CHole => λ e, e
  | CTm e => λ _, e
  | CLam C => λ e, lam (plug C e)
  | CApp C₁ C₂ => λ e, app (plug C₁ e) (plug C₂ e)
  | CSucc C => λ e, succ (plug C e)
  | CRec C Cz Cs => λ e, rec (plug C e) (plug Cz e) (plug Cs e)
  end.

Inductive obs : comp → comp → Prop :=
| OBS c₁ c₂ n : c₁ ⇓ vnat n → c₂ ⇓ vnat n → obs c₁ c₂.

Definition ctxeq Γ σ (e₁ e₂ : expr (dom Γ)) :=
  ∀ C, CCT Γ σ □ t_nat C →
       obs (cev (plug C e₁) ¡) (cev (plug C e₂) ¡).

Lemma compat Γ Δ σ τ e₁ e₂ C (HR : Γ ⊨ e₁ ≈ e₂ : σ) (HTC : CCT Γ σ Δ τ C) :
  Δ ⊨ plug C e₁ ≈ plug C e₂ : τ.
Proof.
  induction HTC; simpl; eauto using C_lam, C_app, C_succ, C_rec, ftlr.
Qed.

Lemma adequacy Γ σ e₁ e₂ (HR : Γ ⊨ e₁ ≈ e₂ : σ) : ctxeq Γ σ e₁ e₂.
Proof.
  intros C HTC; eapply compat in HR; [| eassumption].
  specialize (HR ¡ ¡ ¡); simpl in *; revert HR.
  generalize (cev (plug C e₁) ¡), (cev (plug C e₂) ¡); clear.
  intros _ _ [c₁ c₂ v₁ v₂ HE₁ HE₂ HI]; destruct HI; now exists n.
Qed.

Lemma termination e τ (HT : □ ⊢ e : τ) : ∃ v, cev e ¡ ⇓ v.
Proof.
  apply ftlr in HT; specialize (HT ¡ ¡ ¡).
  revert HT; generalize (cev e ¡) as c; intros c HT.
  inversion HT; subst; clear HT; now exists v₁.
Qed.
