Require Import Utf8.

(** * Operations/extensions of set-based scopes. *)

Notation "∅" := Empty_set.
(* begin details *)
(** typed as [\emptyset] *)
(* end details *)

(** An [inc] type, isomorphic with [option]. *)
Inductive inc {V : Set} : Set :=
| VZ : inc
| VS : V → inc
.
Arguments inc : clear implicits.

(** A map action for standard function space over [inc]. *)
Definition inc_map {X Y : Set} (f : X → Y) (ix : inc X) : inc Y :=
  match ix with
  | VZ => VZ
  | VS x => VS (f x)
  end.

(** A map action for standard function space over [sum] (in its second
  argument). *)
Definition sum_map {X Y Z : Set} (f : Y → Z) (ay : X + Y) : X + Z :=
  match ay with
  | inl x => inl x
  | inr y => inr (f y)
  end.

(** Notations for dependently-typed eliminators  *)
Notation "¡" := (Empty_set_rect _).
Notation "ρ ▷ v" := (inc_rect _ _ v ρ) (at level 40, left associativity).
