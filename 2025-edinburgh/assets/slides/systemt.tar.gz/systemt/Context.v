Require Import Utf8.
Require Export Scope.

(** * Contexts *)

(** A context over V consists of a set of variables (its domain) and a
    map from variables into values of type V. *)
Record Ctx {V : Type} :=
  { dom : Set;
    val :> dom → V
  }.
Arguments Ctx V : clear implicits.

(** Empty context, context extension by a single element, and context
  composition *)
Definition emptyC {V} : Ctx V :=
  {| dom := Empty_set; val x := match x with end |}.
Definition extC {V} (v : V) (Γ : Ctx V) : Ctx V :=
  {| dom := inc (dom Γ); val x := match x with VZ => v | VS x => Γ x end |}.

Definition compC {V} (Γ Δ : Ctx V) : Ctx V :=
  {| dom := (dom Γ) + (dom Δ)
  ;  val x := match x with inl x => Γ x | inr y => Δ y end
  |}.

Notation "□" := emptyC.
Notation "Γ ▹ v" := (extC v Γ) (at level 40, left associativity).
Notation "Γ · Δ" := (compC Γ Δ) (at level 40, left associativity).
(* begin details *)
(** Written as [\square], [\triangleright] and [\cdot] respectively. *)
(* end details *)
